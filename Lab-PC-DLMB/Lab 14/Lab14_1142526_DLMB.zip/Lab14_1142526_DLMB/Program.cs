﻿using System;


namespace Lab14_DLMB_1142536
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("Laboratorio #14: Larissa Méndez - 1142526");
            Console.WriteLine("Ejercicio # 1: CuentaBancaria");

            // Crear una cuenta bancaria
            CuentaBancaria bac = new CuentaBancaria("Andrea Castro", "123477");
            CuentaBancaria bi = new CuentaBancaria("Larissa Méndez", "123456");
            
            //Mostrar Saldo Inicial
            bac.MostrarInfo();
            bi.MostrarInfo();

            //Depositos
            Console.WriteLine("Realizando depósitos...");
            bac.Depositar(500);
            bi.Depositar(100);

            //Saldo
            Console.WriteLine("Saldo: ");
            bac.MostrarInfo();
            bi.MostrarInfo();
            

            // Retiros
            Console.WriteLine("Realizando retiros...");
            bac.Retirar(200);
            bi.Retirar(50);

            // Saldo después de retiros
            Console.WriteLine("Saldo:");
            bac.MostrarInfo();
            bi.MostrarInfo();

            Console.WriteLine("Ejercicio # 2: Productos");
            // Crear un producto
            Producto manzanas = new Producto("Manzanas", 5.00, 10);
            Producto peras = new Producto("Peras", 6.00, 20);

            Console.WriteLine("Información de los productos:");
            manzanas.MostrarInfo();
            peras.MostrarInfo();

            //Ventas 
            Console.WriteLine("Vendiendo productos...");
            manzanas.vender(3);
            peras.vender(5);
            Console.WriteLine("Información de los productos después de la venta:");
            manzanas.MostrarInfo();
            peras.MostrarInfo();       

            // Reabastecer productos 
            Console.WriteLine("Reabasteciendo productos...");
            manzanas.Reabastecer(5);
            peras.Reabastecer(10);
            Console.WriteLine("Información de los productos después del reabastecimiento:");
            manzanas.MostrarInfo();
            peras.MostrarInfo();    
            


            Console.WriteLine("Ejercicio #3: Estudiantes");
            Estudiante est1 = new Estudiante("Carlos Pérez", 18, 10, new double[] { 55.5, 60.0, 80.0, 48.9, 62.0 });
            Estudiante est2 = new Estudiante("Paola Suárez", 19, 11, new double[] { 90.0, 90.0, 95.0, 92.5, 78.0 });
            Estudiante est3 = new Estudiante("Karina Torres", 18, 11, new double[] { 40.0, 50.0, 95.0, 72.5, 78.0 });

            Console.WriteLine("Promedio de cada estudiante:");
           Console.WriteLine(est1.CalcularPromedio());
           Console.WriteLine(est2.CalcularPromedio());
           Console.WriteLine(est3.CalcularPromedio());

            Console.WriteLine("Información de los estudiantes:");
            est1.MostrarInfo();
            est2.MostrarInfo();
            est3.MostrarInfo();

            Console.WriteLine("Estado de los estudiantes: ");
            Console.WriteLine("Estudiante 1:");
            est1.Aprobar(est1.CalcularPromedio());
            Console.WriteLine("Estudiante 2:");
            est2.Aprobar(est2.CalcularPromedio());
            Console.WriteLine("Estudiante 3:");
            est3.Aprobar(est3.CalcularPromedio());

            est1.AgregarNota(85.0);
            est1.CalcularPromedio();
            est1.MostrarInfo();
        }
    }
}  
    
    internal class CuentaBancaria
    {
        //Atributos

        double saldo;
        string titular;
        string numeroCuenta;

        //Constructor
        public CuentaBancaria(string nombreIngresado, string numeroCuentaGenerado)
        { 
            this.titular = nombreIngresado;
            this.numeroCuenta = numeroCuentaGenerado;
            this.saldo = 50; // Saldo inicial en 50
        }

        //Metodos
        //Mostrar info
        public void MostrarInfo()
        {
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Cuenta : " + numeroCuenta.ToString() + " - " + titular);
            Console.WriteLine("Saldo: " + saldo.ToString());
            Console.WriteLine("---------------------------------------------------------------");
        }

        // Depositar
        public void Depositar(double monto)
        {
            this.saldo += monto;
        }

        //Retirar
        public void Retirar(double monto)
        {
            if (saldo >= monto)
            {
                this.saldo -= monto;
                Console.WriteLine("Transaccion completa exitosamente.");
            }
            else
            {
                Console.WriteLine("No se pudo completar la transaccion.");
            }
        }
    }
    //Clase del ejercicio 2: Productos
    internal class Producto
    {
        //atributos
        private string nombre;
        private double precio;
        private int cantidad;
        //Constructor
        public Producto(string nombre, double precio, int cantidad)
        { 
            this.nombre = nombre;
            this.precio = precio;
            this.cantidad = cantidad;
        }
        public void MostrarInfo()
        {
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Producto : " + nombre);
            Console.WriteLine("Precio: " + precio.ToString());
            Console.WriteLine("Cantidad: " + cantidad.ToString());
            Console.WriteLine("---------------------------------------------------------------");
        }
        public void vender(int cantidadVendida)
        {
            if (cantidad >= cantidadVendida)
            {
                this.cantidad -= cantidadVendida;
                Console.WriteLine("Venta realizada exitosamente.");
            }
            else
            {
                Console.WriteLine("No se pudo realizar la venta.");
            }
        }
        public void Reabastecer(int cantidadReabastecida)
        {
            this.cantidad += cantidadReabastecida;
        }
    }

    //Clase del ejercicio 3: Estudiantes
    internal class Estudiante
    {
        //Atributos
        private string nombre;
        private int edad;
        private int grado;
        double[] notas;

        //Constructor
        public Estudiante(string nombre, int edad, int grado, double[] notas)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.grado = grado;
            this.notas = notas;
        }

        public void MostrarInfo()
        {
            Console.WriteLine();
            Console.WriteLine("Estudiante : " + nombre);
            Console.WriteLine("Edad: " + edad.ToString()+" años");
            Console.WriteLine("Grado cursante: " + grado.ToString());
            Console.WriteLine("Promedio: " + CalcularPromedio().ToString());
            Aprobar(CalcularPromedio());
            Console.WriteLine();
        }
        public double CalcularPromedio()
        {
            if(notas.Length == 0){return 0;}
            double suma = 0;
            for (int i = 0; i < notas.Length; i++)
            {
                suma += notas[i];
            }
            return suma / notas.Length;
        }
        public void Aprobar(double promedio)
        {
            if (promedio >= 61.00)
            {
                Console.WriteLine("Aprobado");
            }
            else
            {
                Console.WriteLine("No aprobado");
            }
        }
        public void AgregarNota(double nuevaNota)
        {
                double[] nuevasNotas = new double[notas.Length + 1];
                for (int i = 0; i < notas.Length; i++)
                {
                    nuevasNotas[i] = notas[i];
                }
                nuevasNotas[nuevasNotas.Length - 1] = nuevaNota;
                notas = nuevasNotas;
        }
    }
    