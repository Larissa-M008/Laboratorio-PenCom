using System;

namespace Laboratorio {
   class Persona {
    public string Nombre;
    public int edad;
    public double altura;
    public bool estudiante;
   }
}