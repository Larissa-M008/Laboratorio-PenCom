﻿using System;

namespace Laboratorio {
   class Pensamiento {
      static void Main(string[] args)
      {
         Console.WriteLine("Laboratorio 13, Larissa M. Pensamiento Computacional");
         Console.WriteLine("----------------------------------");
         Console.WriteLine("Ejercicio 1"); //Ejercicio de los datos personales
         Persona per = new Persona();
         Console.WriteLine("Ingrese su nombre: ");
         per.Nombre= Console.ReadLine();
         Console.WriteLine("Ingrese su edad: ");
         per.edad= int.Parse(Console.ReadLine());
         Console.WriteLine("Ingrese su altura (en metros): ");
         per.altura= double.Parse(Console.ReadLine());
         Console.WriteLine("¿Usted es estudiante?");
         Console.WriteLine("1. Soy estudiante");
         Console.WriteLine("2. No soy estudiante");
         int el = int.Parse(Console.ReadLine());
         string eleccion = "";
         if (el == 1)
         {
            per.estudiante =true;
            eleccion = "Es estudiante";
         }
         else 
         {
            per.estudiante=false;
            eleccion = "No es estudiante";
         }

         Console.WriteLine();
         Console.WriteLine("Su nombre es "+per.Nombre+" , su edad es "+per.edad+" , su altura es "+per.altura+"m, "+eleccion);
       
         
         Vehiculo ve = new Vehiculo(); //Ejercicio del Vehiculo
         Console.WriteLine("----------------------------------");
         Console.WriteLine("Ejercicio 2");
         Console.WriteLine("Ingrese la marca de su vehiculo: ");
         ve.marca = Console.ReadLine();
         Console.WriteLine("Ingrese el modelo de su vehiculo: ");
         ve.modelo = Console.ReadLine();
         Console.WriteLine("Ingrese el año de su vehiculo: ");
         ve.anio = int.Parse(Console.ReadLine());
         Console.WriteLine("Ingrese el color de su vehiculo: ");
         ve.color = Console.ReadLine();
         Console.WriteLine("Ingrese la placa de su vehiculo: ");
         ve.placa = Console.ReadLine();

         Console.WriteLine();
         Console.WriteLine("Su vehiculo es de la marca "+ve.marca+", modelo "+ve.modelo);
         Console.WriteLine("del año "+ve.anio+", de color "+ve.color+", y placa: "+ve.placa);

         Console.WriteLine("----------------------------------");
         Console.WriteLine("Ejercicio 3");
         Producto pro = new Producto();// Ejercicio de los productos.
         Console.WriteLine("Ingrese el código del producto: ");
         pro.codigo = Console.ReadLine();
         Console.WriteLine("Ingrese el nombre del producto: ");
         pro.nom = Console.ReadLine();
         Console.WriteLine("Ingrese el precio del producto: ");
         pro.precio = double.Parse(Console.ReadLine());
         Console.WriteLine("Ingrese el stock del producto: ");
         pro.stock = int.Parse(Console.ReadLine());   
         if (pro.stock > 0)
         {
            pro.disponible = true;
         }
         else
         {
            pro.disponible = false;
         }
         Console.WriteLine();
         Console.WriteLine("El producto "+pro.nom+", tiene el código "+pro.codigo);
         Console.WriteLine("Vale Q"+pro.precio+" tiene stock: "+pro.stock+" y "+pro.disponible+" Está disponible");

         Console.WriteLine("----------------------------------");
         Console.WriteLine("Ejercicio 4");
         Mascota mas = new Mascota(); //Ejercicio de las mascotas
         Console.WriteLine("Ingrese el nombre de su mascota: ");
         mas.nombre = Console.ReadLine();
         Console.WriteLine("Ingrese la especie de su mascota: ");
         mas.especie = Console.ReadLine();
         Console.WriteLine("Ingrese la edad de su mascota (en años): ");
         mas.edad = int.Parse(Console.ReadLine());
         Console.WriteLine("Ingrese el peso de su mascota (en libras): ");
         mas.peso = double.Parse(Console.ReadLine());
         Console.WriteLine("¿Su mascota está vacunada?");
         Console.WriteLine("1. Sí");
         Console.WriteLine("2. No");
         int eleccion2 = int.Parse(Console.ReadLine());
         
         if (eleccion2 == 1)
         {
            mas.vacunado = true;
            eleccion = "Está vacunado";
         }
         else
         {
            mas.vacunado = false;
            eleccion= "No está vacunado";
         }

         Console.WriteLine("Su mascota "+mas.nombre+", es un "+mas.especie+", tiene "+mas.edad+" años");
         Console.WriteLine("Pesa "+mas.peso+"lbs. y "+eleccion);
      }
   }
}