using System;

namespace Laboratorio {
   class Producto
    {
        public string codigo;
        public string nom;
        public double precio;
        public int stock;
        public bool disponible;
        
    }
}