﻿using System;
using System.Diagnostics;
using System.Linq.Expressions;

namespace Lab9_DLMB_1142526 {
     class Pensamiento {
          static void Main(string[] args)
        {
            Console.WriteLine("Darlene Larissa Méndez Bedoya 1142526");
            Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingrese cualquier número entero:");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("La suma de sus dígitos es de: ");
            Console.WriteLine(suma(num));

            Console.WriteLine();
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Ingrese su saldo en su cuenta bancaria:");
            double saldo = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el monto a retirar de su cuenta bancaria:");
            double monto = double.Parse(Console.ReadLine());
            
            if (monto > saldo)
               {
                    Console.WriteLine(banco(ref saldo, ref monto));
                    Console.WriteLine("No hubieron cambios");
               }
            else
               {
                    Console.WriteLine("Su saldo es de: ");
                    Console.WriteLine(banco(ref saldo,ref monto));
               }
           
            Console.WriteLine();
            Console.WriteLine("Ejercicio 3");
            Console.WriteLine("GRADOS CELCIUS A FAHRENHEIT");
            Console.WriteLine("Ingrese los grados celsius a convertir: ");
            double gradosc = double.Parse(Console.ReadLine());
            double gradosf = 0;
            Console.WriteLine("En grados Fahrenheit son:");
            Console.WriteLine(grados(gradosc, ref gradosf));

            Console.WriteLine();
            Console.WriteLine("Ejercicio 4");
            Console.WriteLine("SISTEMA DE PUNTOS DE ESTUDIANTE");
            Console.WriteLine("Ingrese los puntos actuales del estudiante: ");
            int puntos = int.Parse(Console.ReadLine());
            Console.WriteLine("Operar las puntos.");
            Console.WriteLine("1.Sumar puntos");
            Console.WriteLine("2.Quitar puntos");
            Console.WriteLine("3.Obtener nivel");
            Console.WriteLine("4.Evaluar Estado");
            int operador = int.Parse(Console.ReadLine());
            
            switch (operador)
               {
                    case 1:
                     Console.WriteLine(AgregarPuntos(ref puntos));
                    break;
                    case 2:
                     Console.WriteLine(menosPuntos(ref puntos));
                    break;
                    case 3:
                     Console.WriteLine(obtenerNivel(puntos));
                    break;
                    case 4:
                      Console.WriteLine(evaluarEstado(puntos));
                    break;
               }
        }
        static int suma (int n)
          {
            int suma = 0;
            while (n>0)
               {
                    suma = suma + (n%10);
                    n = n /10;
               }
            return suma;
          }
       static double banco (ref double s, ref double m)
          {
               if (m > s)
               {
                    return s;
               }
               else
               {
                    s = s-m;
                    return s;
               }
          }
        static double grados (double c, ref double f)
          {
               f=(c*1.8)+32;
               return f;
          }
         static int AgregarPuntos(ref int puntos)
          {
             if (puntos >=100)
               {
                 puntos = 100;  
                 return puntos;  
               } 
               else 
               {
                puntos = puntos + 10;
                return puntos;
               }
          }
         static int menosPuntos(ref int puntos)
          {
             if (puntos <= 0) 
             {
                puntos = 0; 
                return puntos;
              }
             else 
               {
                puntos = puntos - 7;
                return puntos;
               }
          }
         static string obtenerNivel(int puntos)
         {
            if (puntos >= 80) 
               {
                    return "Avanzado";
               }
            if (puntos >= 50) 
               {
                   return "Intermedio";
               }
               else
               {
                return "Básico";  
               }
         }
        static string evaluarEstado(int puntos)
          {
               if (puntos == 100) 
               {
                    return "Excelente";
               }
               if (puntos >= 70) 
               {
                    return "Aprobado";
               }
               else
               {
                  return "Reprobado";  
               }
          }
     }
}
