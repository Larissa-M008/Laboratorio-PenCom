﻿using System;

namespace Proyecto2_DLMB
{
    class Pensamiento
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine("Desarrolladora: Larissa Méndez_1142526");
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine("¡Bienvenido a la Gestión de Granja por Consola!");
            Console.WriteLine("Antes de empezar llena los siguientes datos...");
            //DineroInicial
            Console.Write("Ingrese el dinero inicial: Q");
            double dinero_Ini = double.Parse(Console.ReadLine());   
            Double dinero = dinero_Ini;
            //Empleados
            Console.Write("Ingrese el número de empleados: ");
            int empleados = int.Parse(Console.ReadLine());
            //Sueldos de los empleados
            Console.Write("Ingrese el sueldo de los empleados: Q");
            double sueldo = double.Parse(Console.ReadLine());
            //Meses a simular
            Console.Write("Ingrese el número de meses a simular: ");
            double meses = double.Parse(Console.ReadLine());
            //Datos de las parcelas
            Console.Write("Ingrese el número de filas de la parcela: ");
            int i = int.Parse(Console.ReadLine());
            Console.Write("Ingrese el número de columnas de la parcela: ");
            int j = int.Parse(Console.ReadLine());
            //Matriz de la parcela (objetos)
            Parcela[,] granja1 = new Parcela[i, j];
            //Inicialización de la matriz de parcelas
            for (int g =0; g < i; g++)
            {
                for (int e = 0; e < j; e++)
                {
                    granja1[g, e] = new Parcela();
                }
            }
            //variables locales
            int mes_Actual = 0;
            double ingresos = 0;
            double materiaPrima =0;
            int Trigo = 0;
            int Repollo = 0;
            int Tomate = 0;
            int Calabaza = 0;
            int Esparrago = 0;
            int opcion = 0;
            while (meses >0 && dinero>0 && opcion != 5)
            {
                Console.WriteLine("------------------------------------------------");
                Console.WriteLine("Ingrese el número de la acción que desea realizar:");
                Console.WriteLine("1. Comprar semillas");
                Console.WriteLine("2. Sembrar");
                Console.WriteLine("3. Consultar Parcelas");
                Console.WriteLine("4. Avanzar de mes");
                Console.WriteLine("5. Salir");
                string respuesta = Console.ReadLine();
                
                if (int.TryParse(respuesta, out opcion))
                {
                    switch (opcion)
                    {
                    case 1:
                        //Comprar semillas
                        double utilidad = dinero - (empleados * sueldo);
                        if (utilidad >= 0 && dinero >=100)
                            {
                                Console.WriteLine("------------------------------------------------");
                                Console.WriteLine("COMPRAR SEMILLAS");
                                Console.WriteLine("Ingrese el tipo de planta que desea comprar:");
                                Console.WriteLine("1.Trigo (cuesta Q100)");
                                Console.WriteLine("2.Repollo (cuesta Q180)");
                                Console.WriteLine("3.Tomate (cuesta Q250)");
                                Console.WriteLine("4.Calabaza (cuesta Q220)");
                                Console.WriteLine("5.Espárrago (cuesta Q500)");
                                int tipoPlanta = int.Parse(Console.ReadLine());
                                double precio =0;
                                if (tipoPlanta == 1)
                                {precio = 100;}
                                else if (tipoPlanta == 2)
                                {precio = 180;}
                                else if (tipoPlanta == 3)
                                {precio = 250;}
                                else if (tipoPlanta == 4)
                                {precio = 220;}
                                else if (tipoPlanta == 5)
                                {precio = 500;}
                                Console.Write("Ingrese la cantidad de semillas a comprar: ");
                                int cantidad = int.Parse(Console.ReadLine());
                                if (dinero >= (precio * cantidad))
                                {
                                    dinero -= precio * cantidad;
                                    materiaPrima += (cantidad * precio);
                                    if (tipoPlanta == 1) {Trigo += cantidad;}
                                    else if (tipoPlanta == 2) {Repollo += cantidad;}
                                    else if (tipoPlanta == 3) {Tomate += cantidad;}
                                    else if (tipoPlanta == 4) {Calabaza += cantidad;}
                                    else if (tipoPlanta == 5) {Esparrago += cantidad;}
                                    if (dinero == 0)
                                    {
                                        Console.WriteLine("Has comprado "+cantidad+" semillas por Q"+(precio * cantidad)+". Dinero restante: Q"+dinero);
                                        Console.WriteLine("¡Has agotado tu dinero!");
                                        opcion = 5; // Salir del juego
                                    }
                                    else
                                    {
                                        Console.WriteLine("Has comprado "+cantidad+" semillas por Q"+(precio * cantidad)+". Dinero restante: Q"+dinero);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("No tienes suficiente dinero para comprar esa cantidad de semillas.");
                                }
                            }
                            else
                            {
                                if (utilidad < 0)
                                {
                                    Console.WriteLine("No puedes comprar semillas porque tus gastos son mayores que tus ingresos.");
                                }
                                else if (dinero < 100)
                                {
                                    Console.WriteLine("No tienes suficiente dinero para comprar semillas.");
                                }
                            }
                        break;
                    case 2:
                        //Sembrar
                        Console.WriteLine("------------------------------------------------");
                        Console.WriteLine("SEMBRAR");
                        if (Trigo>0 || Repollo>0 || Tomate>0 || Calabaza>0 || Esparrago>0){
                        Console.Write("Ingrese la fila de la parcela donde desea sembrar: ");
                        int k = int.Parse(Console.ReadLine());
                        Console.Write("Ingrese la columna de la parcela donde desea sembrar: ");
                        int l = int.Parse(Console.ReadLine());
                        if (k < i && l < j)
                            {
                                if (granja1[k, l].matriz_Parcela == "Vacía")
                                {
                                    Console.WriteLine("Ingrese el tipo de planta que desea sembrar:");
                                    Console.WriteLine("1.Trigo");
                                    Console.WriteLine("2.Repollo");
                                    Console.WriteLine("3.Tomate");
                                    Console.WriteLine("4.Calabaza");
                                    Console.WriteLine("5.Espárrago");
                                    int tipoPlanta = int.Parse(Console.ReadLine());
                                    if (tipoPlanta == 1&& Trigo>0)//Trigo
                                    {granja1[k, l].matriz_Parcela = "Trigo";
                                    granja1[k,l].meses_Finales=1;
                                    granja1[k,l].ganancia_Parcela=130;
                                    Trigo--;}
                                    else if (tipoPlanta == 2&& Repollo>0)//Repollo
                                    {granja1[k, l].matriz_Parcela = "Repollo";
                                    granja1[k,l].meses_Finales=2;
                                    granja1[k,l].ganancia_Parcela=280;
                                    Repollo--;}
                                    else if (tipoPlanta == 3&& Tomate>0)//tomate
                                    {granja1[k, l].matriz_Parcela = "Tomate";
                                    granja1[k,l].meses_Finales=3;
                                    granja1[k,l].ganancia_Parcela=450;
                                    Tomate--;}
                                    else if (tipoPlanta == 4&& Calabaza>0)//calabaza
                                    {granja1[k, l].matriz_Parcela = "Calabaza";
                                    granja1[k,l].meses_Finales=4;
                                    granja1[k,l].ganancia_Parcela=360;
                                    Calabaza--;}
                                    else if (tipoPlanta == 5&& Esparrago>0)//espárrago
                                    {granja1[k, l].matriz_Parcela = "Espárrago";
                                    granja1[k,l].meses_Finales=6;
                                    granja1[k,l].ganancia_Parcela=1000;
                                    Esparrago--;}
                                    Console.WriteLine("Has sembrado "+granja1[k, l].matriz_Parcela+" en la parcela ("+k+", "+l+").");
                                }
                                else
                                {
                                    Console.WriteLine("La parcela ("+k+", "+l+") ya tiene una planta sembrada.");
                                }
                             }
                            }
                             else
                            {
                                 Console.WriteLine("No tienes semillas disponibles para sembrar. Compra semillas.");
                            }
                        break;
                    case 3:
                        //Consultar Parcelas
                        Console.WriteLine("------------------------------------------------");
                        Console.WriteLine("CONSULTAR PARCELAS");
                        Console.Write("Ingrese la fila de la parcela que desea consultar: ");
                        int k1 = int.Parse(Console.ReadLine());
                        Console.Write("Ingrese la columna de la parcela que desea consultar: ");
                        int l1 = int.Parse(Console.ReadLine());
                        Console.WriteLine("------------------------------------------------");
                        if (k1 >=0 && k1 < i && l1 >=0 && l1 < j)
                            {
                               Console.WriteLine("Estado de la parcela: "+ granja1[k1,l1].matriz_Parcela);
                            
                            if (granja1[k1,l1].matriz_Parcela != "Vacía")
                            {
                                Console.WriteLine("Mes actual: "+mes_Actual);
                                Console.WriteLine("Meses restantes: "+granja1[k1,l1].meses_Finales);
                                Console.WriteLine("Las ganancias esperadas son: Q"+ granja1[k1,l1].ganancia_Parcela);
                            }
                            }
                            else
                            {
                                Console.WriteLine("La parcela ("+k1+", "+l1+") no existe. Por favor, ingrese coordenadas válidas.");
                            }
                            
                        break;
                    case 4:
                        //Avanzar de mes
                        Console.WriteLine("------------------------------------------------");
                        Console.WriteLine("AVANZAR DE MES");
                        double CostosMensuales = empleados * sueldo;
                        dinero -= CostosMensuales;
                        mes_Actual++;
                        meses--;
                        Console.WriteLine("Estás en el mes: "+mes_Actual+" de la simulación.");
                        Console.WriteLine("Has pagado Q"+CostosMensuales+" en sueldos. Dinero restante: Q"+dinero);
                        Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - -");
                        for (int g =0; g < i; g++)
                            {
                                for (int e = 0; e < j; e++)
                                {
                                    if (granja1[g,e].matriz_Parcela != "Vacía")
                                    {
                                        granja1[g,e].meses_Finales--;
                                        if (granja1[g,e].meses_Finales == 0)
                                        {
                                            dinero += granja1[g,e].ganancia_Parcela;
                                            ingresos += granja1[g,e].ganancia_Parcela;
                                            Console.WriteLine("La parcela ("+g+", "+e+") ha generado Q"+granja1[g,e].ganancia_Parcela);
                                            granja1[g,e].matriz_Parcela = "Vacía";
                                            granja1[g,e].ganancia_Parcela = 0;
                                        }
                                        else
                                        {
                                            Console.WriteLine("La parcela ("+g+", "+e+") está a "+granja1[g,e].meses_Finales+" meses restantes para generar ganancias.");
                                        }
                                    }
                                }
                            }
                        break;
                    case 5:
                        Console.WriteLine("------------------------------------------------");
                        Console.WriteLine("¡Gracias por usar la Gestión de Granja por Consola!");
                        Console.WriteLine("Saliendo del programa...");
                        break;
                    default:
                        Console.WriteLine("Entrada no válida. Por favor, ingrese un número del 1 al 5.");
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Entrada no válida. Por favor, ingrese un número del 1 al 5.");
                }
            }
            Console.WriteLine("------------------------------------------------");
                        Console.WriteLine("REPORTE FINAL");
                        double costosTotales = (empleados * sueldo) * mes_Actual;
                        double utilidadFinal = (dinero_Ini + ingresos) - (costosTotales + materiaPrima);
                        Console.WriteLine("Dinero inicial: Q"+dinero_Ini);
                        Console.WriteLine("Ingresos por cosecha: Q"+ingresos);
                        Console.WriteLine("Gastos totales en semillas: Q"+materiaPrima);
                        Console.WriteLine("Costos totales en empleados: Q"+costosTotales);
                        Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - -");
                        Console.WriteLine("Utilidad final: Q"+utilidadFinal);
        }
     }
        internal class Parcela
        {
        private string _matriz_Parcela = "Vacía";
        private int _meses_Finales = 0;
        private double _ganancia_Parcela = 0;

        public string matriz_Parcela
        {
        get { return _matriz_Parcela; }
        set { _matriz_Parcela = value; }
        }

        public int meses_Finales
        {
        get { return _meses_Finales; }
        set { _meses_Finales = value; }
        }

        public double ganancia_Parcela
        {
        get { return _ganancia_Parcela; }
        set { _ganancia_Parcela = value; }
        }
    }
}