﻿using System;
using System.Dynamic;

namespace Lab15_DLMB_1142526
{
    class Pensamiento
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-------------------------------");
            Console.WriteLine("Larissa Méndez, lab 15, 1142526");
            Console.WriteLine("Ejercicio 1");
            //Prueba 1
            double saldo = 500.00;
            RetirarEfectivo(ref saldo, 100);
            Console.WriteLine("saldo: "+saldo);
            //Prueba 2
            RetirarEfectivo(ref saldo, 600);
            Console.WriteLine("saldo: "+saldo);
            //Prueba3
            double saldo2 =0.00;
            RetirarEfectivo(ref saldo2, 100);
            Console.WriteLine("saldo: "+  saldo2);
            Console.WriteLine("-------------------------------");
            Console.WriteLine("Ejercicio 2");
            double precio1 = 100.00;
            double precio2 = 0.0;
            //Prueba 1
            double descuento1 = CalcularDescuento(precio1, 10);
            Console.WriteLine("Q"+descuento1);
            //Prueba 2
            double descuento2 = CalcularDescuento(precio1, 50);
            Console.WriteLine("Q"+descuento2);
            //Prueba 3
        
            double descuento3 = CalcularDescuento(precio2, 50);
            Console.WriteLine("Q"+descuento3);
            //Prueba 4
            double descuento4 = CalcularDescuento(precio1, 100);
            Console.WriteLine("Q"+descuento4);
            Console.WriteLine("-------------------------------");
            Console.WriteLine("Ejercicio 3");
            double SALDO1 = 100.00;
            //Prueba1
            Depositar(ref SALDO1,500);
            Console.WriteLine("Saldo después de depositar: Q" + SALDO1);
            //Prueba2
            Depositar(ref SALDO1,-200);
            Console.WriteLine("Saldo después de depositar: Q" + SALDO1);
            //Prueba3
            Depositar(ref SALDO1,0);
            Console.WriteLine("Saldo después de depositar: Q" + SALDO1);
             Console.WriteLine("-------------------------------");
            Console.WriteLine("Ejercicio 4");
            double capital = 1000.00;
            double tasa = 0.05;
            double intereses = 0;
            double abonos = 0;

            for (int mes=0; mes<=12 && capital > 0; mes++)
            {
                //Cálculo de intereses del mes
                intereses = capital * tasa;
                //Abono mensual
                abonos = 100 + (mes * 10);
                //Actualización del capital
                capital = capital + intereses - abonos;
            }
        }
    
    static void RetirarEfectivo(ref double saldo, double montoRetirado)
            {
                if (saldo == 0.00)
                {
                    Console.WriteLine("Saldo Insuficiente.");
                    return;
                }
                else if (montoRetirado > saldo)
                {
                    Console.WriteLine("Saldo insuficiente.");
                    return;
                }
                saldo = saldo - montoRetirado;
            }
    
    static double CalcularDescuento(double precio, double porcentaje)
        {
            if (precio == 0.00)
            {
                Console.WriteLine("Precio debe ser mayor a Q0.00");
                return 0.00;
            }
            else if (porcentaje < 0 || porcentaje > 100)
            {
                Console.WriteLine("Porcentaje de descuento no válido.");
                return precio;
            }
            return precio - (precio * porcentaje/100);
        }
        static void Depositar(ref double saldo, double monto)
        {
            if (monto <= 0)
            {
                Console.WriteLine("Monto de depósito no válido.");
                return;
            }
            saldo = saldo + monto;
        }
 }
}
    
