﻿using System;

namespace Laboratorio {
   class Pensamiento {
      static void Main(string[] args) {
         Console.WriteLine("========================================");
         Console.WriteLine("Laboratorio 12, Pensamiento Computacional");
         Console.WriteLine("Larissa Méndez Bedoya");
         Console.WriteLine("========================================");


         Console.WriteLine("Ejercicio 1: SUMA de diagonales");
         int [,] matriz5 = new int[5,5];
         LlenarMa(matriz5);

         Console.WriteLine("La suma de la diagonal principal es de: ");
         Console.WriteLine(sumaDiPri(matriz5));
         Console.WriteLine("La suma de la diagonal secundaria es de: ");
         Console.WriteLine(SumaDiSeg(matriz5));

         Console.WriteLine("========================================");
         Console.WriteLine("Ejercicio 2: Números PARES e IMPARES");
         int [,] matriz2 = new int[4,6];
         LlenarMa2(matriz2);
         Console.WriteLine("Números pares:");
         Console.WriteLine(NumPar(matriz2));
         Console.WriteLine("Números impares:");
         Console.WriteLine(NumNOPar(matriz2));

         Console.WriteLine("========================================");
         Console.WriteLine("Ejercicio 3: Notas de 5 estudiantes");
         float [,] matriz3 = new float[5,4];
         LlenarMa3(matriz3);
         Console.WriteLine("Las estadísticas por estudiante son: ");
         for (int i =0; i<5;i++)
         {
            float prom = PromedioEst(matriz3, i);
            bool apr= Aprobados(prom);
            Console.WriteLine("El promedio del estudiantes No."+(i+1)+" es de: "+prom);
            if (apr == true)
            {
               Console.WriteLine("Aprobado");
            }
            else
            {
               Console.WriteLine("Reprobado");
            }
         }
         Console.WriteLine("========================================");
         Console.WriteLine("Ejercicio 4: matriz simetrica...o no");
         int[,] matrizsimétrica = new int [3,3];
         LlenarMAAA(matrizsimétrica);
         if (simetrica(matrizsimétrica)== true)
         {
            Console.WriteLine("La matriz SI es simetrica");
         }
         else
         {
            Console.WriteLine("La matriz NO es simetrica");
         }

      }
      static void LlenarMa(int [,] ma)
      {
         for (int i=0; i<5; i++)
         {
            for (int j=0; j<5; j++)
            {
               Console.WriteLine("Ingrese un número:");
               int llenar = int.Parse(Console.ReadLine());
               ma[i,j] = llenar;
            }
         }
      }
       static int sumaDiPri(int[,] m)
      {
         int suma=0;
         for (int i =0; i<5; i++)
         {
            suma = suma + m[i,i];
         }
         return suma;
      }
      static int SumaDiSeg(int[,] m)
      {
         int suma=0;
         for (int i=0; i<5; i++)
         {
            suma = suma + m[i,4-i];
         }
         return suma;
      }
       static void LlenarMa2(int [,] ma)
      {
         for (int i=0; i<4; i++)
         {
            for (int j=0; j<6; j++)
            {
               Console.WriteLine("Ingrese un número:");
               int llenar = int.Parse(Console.ReadLine());
               ma[i,j] = llenar;
            }
         }
      }
      static int NumPar (int [,] m)
      {
         int contador=0;
         for (int i=0; i<4; i++)
         {
            for (int j=0; j < 6; j++)
            {
               if (m[i,j]% 2 == 0)
               {
                  contador++;
               }
            }
         }
         return contador;
      }
      static int NumNOPar (int [,] m)
      {
         int contador=0;
         for (int i=0; i<4; i++)
         {
            for (int j=0; j < 6; j++)
            {
               if (m[i,j]% 2 != 0)
               {
                  contador++;
               }
            }
         }return contador;
      }
       static void LlenarMa3(float [,] ma)
      {
         for (int i=0; i<5; i++)
         {
            Console.WriteLine("Ingrese la nota del alumno No."+ (i+1) +":");
            for (int j=0; j<4; j++)
            {
               float llenar = float.Parse(Console.ReadLine());
               ma[i,j] = llenar;
            }
         }
      }
      static float PromedioEst(float[,] m, int est)
      {
         float suma =0;
         for (int j=0; j<4; j++)
         {
            suma = suma + m[est,j];
         }
         return suma/4;
      }
      static bool Aprobados(float p)
      {
         if (p >= 61)
         {
            return true;
         }
         else
         {
            return false;
         }
      }
      static void LlenarMAAA(int [,] ma)
      {
         for (int i=0; i<3; i++)
         {
            for (int j=0; j<3; j++)
            {
               Console.WriteLine("Ingrese un número:");
               int llenar = int.Parse(Console.ReadLine());
               ma[i,j] = llenar;
            }
         }
      }
      static bool simetrica(int[,] m)
      {
         for (int i=0; i <3; i++)
         {
            for(int j=0; j<3; j++)
            {
               if (m[i,j] != m[j,i])
               {
                  return false;
               }
            }
         }
         return true;
      }
   }
}