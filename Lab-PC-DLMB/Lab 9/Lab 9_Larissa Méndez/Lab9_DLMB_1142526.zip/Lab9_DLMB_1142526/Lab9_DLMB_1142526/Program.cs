﻿using System;
using System.Diagnostics;
using System.Linq.Expressions;

namespace Lab9_DLMB_1142526 {
     class Pensamiento {
          static void Main(string[] args) {
          Console.WriteLine ("Larissa Méndez_1142526 Lab 9");
          Console.WriteLine("Ejercicio 1");
          Console.WriteLine ("Ingrese una palabra: ");
         string pal=Console.ReadLine();
         num(pal);
         Console.WriteLine();

         Console.WriteLine("Ejercicio 2");
         Console.WriteLine ("El valor de a es 4 y el valor de b es 13");
         int a = 4;
         int b = 13;
         posi (ref a, ref b);
         Console.WriteLine();

         Console.WriteLine("Ejercicio 3");
         int boleto = 50;
         double descuento1 = 0.5;
         double desc2 =0.15;
         double desc3= 0.9;

         Console.WriteLine("El boleto vale: "+boleto);
         Console.WriteLine("Ingrese que tipo de cliente es:");
         Console.WriteLine("1. Niño");
         Console.WriteLine("2. Adulto Mayor");
         Console.WriteLine("3. VIP");
         Console.WriteLine("4. Adulto");
         int cliente =int.Parse(Console.ReadLine());

         porcentaje(boleto, cliente, ref descuento1, ref desc2, ref desc3);
         Console.WriteLine();

         Console.WriteLine("Ejercicio 4");
         int puntosSalud= 15;
         int elegir;
         do 
         {
         Console.WriteLine("La vida del personaje es: "+puntosSalud);
         Console.WriteLine("Opciones para la vida del personaje: ");
         Console.WriteLine("1. Atacar al personaje");
         Console.WriteLine("2. Curar al personaje");
         Console.WriteLine("3. Mostrar salud actual");
         Console.WriteLine("4. Desempeño final");
         Console.WriteLine();
         elegir = int.Parse(Console.ReadLine());
         Console.WriteLine();
          switch (elegir)
            {
                case 1:
                recibirDaño (ref puntosSalud);
                mostrarSalud(puntosSalud);
                break;
                case 2:
                curar(ref puntosSalud);
                mostrarSalud(puntosSalud);
                break;
                case 3:
                mostrarSalud(puntosSalud);
                break;
                case 4:
                mostrarSalud(puntosSalud);
                calificarDesempeño(puntosSalud);
                
                break;
                default:
                Console.WriteLine("Esa opción no es válida.");
                break;

            }
           
         } while (elegir !=4 && puntosSalud>0);
         
    }
    static void posi(ref int a, ref int b)
    {
        int c = a;
        a = b;
        b = c;
        Console.WriteLine("el valor de a es "+a+", el valor de b es ahora "+b);
    }
    static void num(string a)
    {
        int largo = a.Length;
        Console.WriteLine("el largo de la palabra es "+largo);
    }
    static void porcentaje(int b, int cli, ref double d1, ref double d2, ref double d3)
    {
        double precio = 0;
        switch (cli)
        {
            case 1: 
            precio = b-(b*d1);
            Console.WriteLine("Su precio con descuento es de: "+precio);
            break;
            case 2:
            precio = b-(b*d2);
            Console.WriteLine("Su precio con descuento es de: "+precio);
            break;
            case 3:
            precio = b-(b*d3);
            Console.WriteLine("Su precio con descuento es de: "+precio);
            break;
            default:
            precio = b;
            Console.WriteLine("Su precio con descuento es de: "+precio);
            break;
        }
    }
    static void recibirDaño(ref int salud)
        {
           salud-=5;
           if (salud < 0)
            {
                salud = 0;
            } 
        }
    static void mostrarSalud(int salud)
        {
            if (salud>=11)
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }
            else if (salud<10 || salud>=6)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
            else if ( salud<5 || salud>=0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            Console.WriteLine("Quedan "+salud+" puntos de vida.");
            Console.ForegroundColor = ConsoleColor.White;
        }
    static void curar(ref int salud)
        {
            salud = salud + 3;
            if (salud>15)
            {
                salud = 15;
            }
        }
    static void calificarDesempeño(int salud)
        {
            if (salud==15)
            {
                Console.WriteLine("Calificación : S");
            }
            else if (salud==14 || salud>=11)
            {
                Console.WriteLine("Calificación : A");
            }
            else if (salud==10 || salud>=6)
            {
                Console.WriteLine("Calificación: B");
            }
            else if (salud==5 || salud>=1)
            {
                Console.WriteLine("Calificación: C");
            }
        }
 }

}